﻿namespace Test_Taste_Console_Application.Constants
{
    public class ConfigurationFileName
    {
        public const string Logger = "log4net.config";
    }
}
